package com.okta.spring.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.okta.commons.http.config.Proxy;
import com.okta.sdk.authc.credentials.TokenClientCredentials;
import com.okta.sdk.client.Client;
import com.okta.sdk.client.Clients;
import com.okta.sdk.resource.user.User;
import com.okta.sdk.resource.user.UserList;
import com.okta.sdk.resource.user.factor.FactorType;
import com.okta.sdk.resource.user.factor.SmsUserFactor;
import com.okta.sdk.resource.user.factor.UserFactor;
import com.okta.sdk.resource.user.factor.UserFactorList;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@SpringBootApplication
public class MgmtSample {
    private static Client client;

    public static void main(String[] args) {
        SpringApplication.run(MgmtSample.class, args);
        //mvn -Dokta.org=https://{org}.okta.com -Dokta.token={API_TOKEN}} -Dproxy.host=10.0.0.244 -Dproxy.port=9090
        //curl http://localhost:8000/run?user=igor.dean@oktaice.com\&phone=9259989770 
    }

    @Configuration
    static class OktaOAuth2WebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            client = Clients.builder()
                .setOrgUrl(System.getProperty("okta.org"))
                .setClientCredentials(new TokenClientCredentials(System.getProperty("okta.token")))
                .setProxy(new Proxy(System.getProperty("proxy.host"), Integer.parseInt(System.getProperty("proxy.port"))))
                .setRetryMaxAttempts(3)
                .setConnectionTimeout(30)
                .setRetryMaxElapsed(10)
                .build();
        }
    }

    @RestController
    public class OktaMgmtSerialCommands {

        @GetMapping("/run")
        public Map<String, Object> run(@RequestParam String user, @RequestParam String phone) {
            Map<String, Object> result = new HashMap<>();
            
            UserList userlist = client.listUsers(user, null, null, null, null);
            User oktaUser = userlist.stream().findFirst().get();
            result.put("user", oktaUser.getProfile().getLogin());
            UserFactorList factors = oktaUser.listFactors();
            Optional<UserFactor> factorToDeleteOpt = factors.stream().filter(s -> s.getFactorType() == FactorType.SMS).findFirst();
            factorToDeleteOpt.ifPresent(factor -> oktaUser.deleteFactor(factor.getId()));
            factorToDeleteOpt.ifPresent(factor -> result.put("factor_id", factor.getId()));
            SmsUserFactor smsFactor = client.instantiate(SmsUserFactor.class);
            smsFactor.getProfile().setPhoneNumber(phone);
            UserFactor f = oktaUser.enrollFactor(smsFactor, true, null, null, true);
            result.put("new_factor_id", f.getId());
            
            return result;
        }
    }
}
